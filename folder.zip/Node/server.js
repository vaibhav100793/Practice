const exp=require('express');
var app=exp();
var empRelatedRoute=require('./routes/emp.js');
app.use((request,response,next)=>{
    response.setHeader('Access-Control-Allow-Origin',"*");
    response.setHeader('Access-Control-Allow-Headers',"*");
    response.setHeader('Access-Control-Allow-Methods',"*");
    next();
})
app.use(exp.json());
app.use('/emp',empRelatedRoute);
app.listen(9999,()=>{
    console.log("SERVER WORKING");
})