const sql=require('mysql');
var connection=sql.createConnection({
     host     : 'localhost',
  user     : 'root',
  password : 'manager',
  database : 'nodejs'
});
const exp=require('express');
var appforEmp=exp.Router();

appforEmp.get("/",(request,response)=>{
    var qry=`select * from Emp`;
connection.query(qry,(error,result)=>{
    if(error==null){
        var data=JSON.stringify(result);
        response.setHeader("Content-Type","application/json");
        response.write(data);
    }
    else{
        console.log(error);
        response.setHeader("Content-Type","application/json");
        response.write(error);

    }
    response.end();
})
})
appforEmp.post("/",(request,response)=>{
    var qry=`insert into Emp values(${request.body.Eno},'${request.body.Ename}','${request.body.Eaddress}')`;
    connection.query(qry,(error,result)=>{
        if(error==null)
        {
            var data=JSON.stringify(result);
            response.setHeader("Content-Type","application/json");
            response.write(data);
        }
        else{

            response.setHeader("Content-Type","application/json");
            response.write(error);
        }
        response.end();
    })
})
appforEmp.put("/:Eno",(request,response)=>{
    var qry=`update Emp set Ename='${request.body.Ename}',Eaddress='${request.body.Eaddress}' where Eno=${request.params.Eno}`;
    connection.query(qry,(error,result)=>{
        if(error==null){
            var data=JSON.stringify(result);
            response.setHeader("Content-Type","application/json");
            response.write(data);
        }
        else{
            console.log(error);
            response.setHeader("Content-Type","application/json");
            response.write(error);
        }
        response.end();
    })
})
appforEmp.delete("/:Eno",(request,response)=>{
    var qry=`delete  from Emp where Eno =${request.params.Eno}`;
    connection.query(qry,(error,result)=>{
        if(error==null){
            var data =JSON.stringify(result);
            response.setHeader("Content-TYpe","application/json");
            response.write(data);
        }
        else{
            console.log(error);
            response.setHeader("Content-Type","appliction/json");
            response.write(error);
        }
        response.end();
    })
})
module.exports=appforEmp;
